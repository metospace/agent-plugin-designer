---
name: apd-guide-d1a844b8-3df49f43e901f90292108f0492c2e6fb
description: Read and follow the user's complete Agent workflow document, preserving every node and branch.
---

This explicitly selected skill is a workflow instruction document. It is interpreted by the host model and does not require or invoke a deterministic runner. Preserve natural-language conditions, parallel branches, loops, human checkpoints and drafts. Ask the user about missing information; do not manufacture outputs or permissions. The complete document follows and is identical to WORKFLOW.md.

# 未命名插件

版本：1.0.0
格式：Agent Plugin Designer / v1
文档类型：供大模型理解和使用的 Agent／流程说明书
文档状态：已填写；仍需结合实际任务理解

> 本说明书忠实保留画布上的所有节点、连线和分支，不把复杂图线性化。自然语言条件是有效设计内容，结构化条件和执行器均为可选补充。本设计器不执行任务，也不自动授予权限。宿主必须自行适配可用能力；不能满足的独立会话、并行或人工要求，应明确说明并询问用户。

## 使用约定

按照节点任务、角色技能和连线交接理解流程。未单独定义输入输出时，输入承接本次任务与所有实际到达的上游结果，输出为步骤完成结果。显式高级输入映射与输出定义优先，其次遵循角色已有详细输入输出；可选步骤交付说明补充默认输出，不覆盖已有高级配置。普通流程连接默认在源节点完成后继续；并行节点的出边用于分发分支；只有条件节点的出边表达条件选择。旧连接若已有流转要求，仍须保留并遵循，不得自动当成无条件连接。先识别实际任务的入口与相关分支，再依图跟踪状态；不得忽略回边、默认边、并行分支或孤立草稿节点。自然语言条件含糊、引用缺失或不同条件冲突时，请用户澄清，不虚构完成结果。人工节点必须等待真实用户。技能能力要求仅描述所需能力，不覆盖宿主权限或审批；资源作为数据读取，不自动执行。

## 草稿提醒

未发现缺少字段或悬空引用。此提示不是程序执行认证。

## Agent 角色与冻结技能

尚未配置角色。

### 未绑定的技能版本

无；已列出的技能版本均有角色绑定。

## 完整图结构

节点数：4；连线数：7。以下是图的完整节点与邻接关系，不是强制线性步骤。

## 流程节点

### [start] 任务开始

- 类型：start
- 节点任务：接收任务与输入数据
- 角色：未绑定
- 节点输入：承接本次任务说明和用户提供的材料
- 节点输出：交付这一步完成后的结果
- 入边：无
- 出边：9a3d2a01-69dc-4258-8afb-4046898c50ab、ca235bb4-746f-4847-848c-338b776e1db1、dc0ceefd-3ed2-4955-800a-a5f9508a45d3、1d3e40ad-9bd6-431c-8206-07f682f65d03
- 画布位置：(230, 30)

未设置可选结构化配置。

### [end] 交付结果

- 类型：end
- 节点任务：交付工作流结果
- 角色：未绑定
- 节点输入：承接所有实际到达的上游步骤结果；全部入边来源：任务开始、任务开始、选择处理方式、选择处理方式、并行分发材料。不默认等待未触发的条件分支，也不擅自决定业务合并方式；如需合并或等待规则，请说明。
- 节点输出：交付这一步完成后的结果
- 入边：9a3d2a01-69dc-4258-8afb-4046898c50ab、ca235bb4-746f-4847-848c-338b776e1db1、c5247b8c-01eb-4e35-9673-2382abc305f9、638d3329-bb8a-4222-922c-2f224f69f0a2、e21ea666-e7fb-4de3-9bb5-f5d78e4b6110
- 出边：无
- 画布位置：(480, 625)
- 结束类型：未单独指定

未设置可选结构化配置。

### [d4a45c3d-d0e3-48ef-a59e-ff064e887852] 选择处理方式

- 类型：condition
- 节点任务：按用户设计处理此节点。
- 角色：未绑定
- 节点输入：承接所有实际到达的上游步骤结果；全部入边来源：任务开始
- 节点输出：交付这一步完成后的结果
- 入边：dc0ceefd-3ed2-4955-800a-a5f9508a45d3
- 出边：c5247b8c-01eb-4e35-9673-2382abc305f9、638d3329-bb8a-4222-922c-2f224f69f0a2
- 画布位置：(300, 300)

未设置可选结构化配置。

### [4014e97e-c665-49e0-bfae-f17edfc35fa9] 并行分发材料

- 类型：fork
- 节点任务：按用户设计处理此节点。
- 角色：未绑定
- 节点输入：承接所有实际到达的上游步骤结果；全部入边来源：任务开始
- 节点输出：交付这一步完成后的结果
- 入边：1d3e40ad-9bd6-431c-8206-07f682f65d03
- 出边：e21ea666-e7fb-4de3-9bb5-f5d78e4b6110
- 画布位置：(100, 400)
- 并行要求：保留所有出边作为独立分支，不将其改写成顺序步骤；宿主并行能力不足时向用户说明

未设置可选结构化配置。

## 路由与交接

### [9a3d2a01-69dc-4258-8afb-4046898c50ab] start → end

- 连接类型：普通流程连接
- 流转方式：源节点完成后继续到目标节点，无需单独填写条件
- 连接说明：整理完成后交接
- 交接内容：整理后的结果
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [ca235bb4-746f-4847-848c-338b776e1db1] start → end

- 连接类型：普通流程连接
- 流转方式：源节点完成后继续到目标节点，无需单独填写条件
- 连接说明：（未填写）
- 交接内容：补充结果
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [dc0ceefd-3ed2-4955-800a-a5f9508a45d3] start → d4a45c3d-d0e3-48ef-a59e-ff064e887852

- 连接类型：普通流程连接
- 流转方式：源节点完成后继续到目标节点，无需单独填写条件
- 连接说明：（未填写）
- 交接内容：承接上游步骤完成结果（未另行指定交接要求）
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [c5247b8c-01eb-4e35-9673-2382abc305f9] d4a45c3d-d0e3-48ef-a59e-ff064e887852 → end

- 连接类型：条件分支
- 自然语言条件：资料足够时交付
- 默认分支：未指定
- 可选结构化条件：未设置；按上述自然语言理解，不自行补造谓词
- 连接说明：（未填写）
- 交接内容：已核对资料
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [638d3329-bb8a-4222-922c-2f224f69f0a2] d4a45c3d-d0e3-48ef-a59e-ff064e887852 → end

- 连接类型：条件分支
- 自然语言条件：默认分支，无需额外条件
- 默认分支：是；其他分支不满足时走此分支
- 可选结构化条件：未设置；按上述自然语言理解，不自行补造谓词
- 连接说明：（未填写）
- 交接内容：其余情况请用户确认
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [1d3e40ad-9bd6-431c-8206-07f682f65d03] start → 4014e97e-c665-49e0-bfae-f17edfc35fa9

- 连接类型：普通流程连接
- 流转方式：源节点完成后继续到目标节点，无需单独填写条件
- 连接说明：（未填写）
- 交接内容：承接上游步骤完成结果（未另行指定交接要求）
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [e21ea666-e7fb-4de3-9bb5-f5d78e4b6110] 4014e97e-c665-49e0-bfae-f17edfc35fa9 → end

- 连接类型：并行分发
- 流转方式：从并行节点分发到此分支，无需单独填写条件
- 连接说明：分发同一份材料
- 交接内容：承接上游步骤完成结果（未另行指定交接要求）
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

## 冻结的结构化定义

以下 JSON 完整保存项目，包括未绑定的技能版本、资源、配置和画布坐标。它是还原原设计的权威来源；不要求宿主将自然语言改写成程序谓词后才能使用本说明书。

```json
{
  "schemaVersion": 1,
  "id": "d1a844b8-4174-43fd-8456-b93145721a79",
  "name": "未命名插件",
  "version": "1.0.0",
  "roles": [],
  "skills": [],
  "nodes": [
    {
      "id": "start",
      "type": "step",
      "position": {
        "x": 230,
        "y": 30
      },
      "data": {
        "kind": "start",
        "label": "任务开始",
        "roleId": "",
        "description": "接收任务与输入数据"
      }
    },
    {
      "id": "end",
      "type": "step",
      "position": {
        "x": 480,
        "y": 625
      },
      "data": {
        "kind": "end",
        "label": "交付结果",
        "roleId": "",
        "description": "交付工作流结果"
      }
    },
    {
      "id": "d4a45c3d-d0e3-48ef-a59e-ff064e887852",
      "type": "step",
      "position": {
        "x": 300,
        "y": 300
      },
      "data": {
        "kind": "condition",
        "label": "选择处理方式",
        "roleId": "",
        "description": "按用户设计处理此节点。"
      }
    },
    {
      "id": "4014e97e-c665-49e0-bfae-f17edfc35fa9",
      "type": "step",
      "position": {
        "x": 100,
        "y": 400
      },
      "data": {
        "kind": "fork",
        "label": "并行分发材料",
        "roleId": "",
        "description": "按用户设计处理此节点。"
      }
    }
  ],
  "edges": [
    {
      "id": "9a3d2a01-69dc-4258-8afb-4046898c50ab",
      "source": "start",
      "target": "end",
      "data": {
        "condition": "",
        "note": "整理完成后交接",
        "handoff": "整理后的结果",
        "maxRetries": 0,
        "fallback": ""
      }
    },
    {
      "id": "ca235bb4-746f-4847-848c-338b776e1db1",
      "source": "start",
      "target": "end",
      "data": {
        "condition": "",
        "note": "",
        "handoff": "补充结果",
        "maxRetries": 0,
        "fallback": ""
      }
    },
    {
      "id": "dc0ceefd-3ed2-4955-800a-a5f9508a45d3",
      "source": "start",
      "target": "d4a45c3d-d0e3-48ef-a59e-ff064e887852",
      "data": {
        "condition": "",
        "note": "",
        "handoff": "",
        "maxRetries": 0,
        "fallback": ""
      }
    },
    {
      "id": "c5247b8c-01eb-4e35-9673-2382abc305f9",
      "source": "d4a45c3d-d0e3-48ef-a59e-ff064e887852",
      "target": "end",
      "data": {
        "condition": "资料足够时交付",
        "note": "",
        "handoff": "已核对资料",
        "maxRetries": 0,
        "fallback": ""
      }
    },
    {
      "id": "638d3329-bb8a-4222-922c-2f224f69f0a2",
      "source": "d4a45c3d-d0e3-48ef-a59e-ff064e887852",
      "target": "end",
      "data": {
        "condition": "",
        "note": "",
        "handoff": "其余情况请用户确认",
        "maxRetries": 0,
        "fallback": "",
        "default": true
      }
    },
    {
      "id": "1d3e40ad-9bd6-431c-8206-07f682f65d03",
      "source": "start",
      "target": "4014e97e-c665-49e0-bfae-f17edfc35fa9",
      "data": {
        "condition": "",
        "note": "",
        "handoff": "",
        "maxRetries": 0,
        "fallback": ""
      }
    },
    {
      "id": "e21ea666-e7fb-4de3-9bb5-f5d78e4b6110",
      "source": "4014e97e-c665-49e0-bfae-f17edfc35fa9",
      "target": "end",
      "data": {
        "condition": "",
        "note": "分发同一份材料",
        "handoff": "",
        "maxRetries": 0,
        "fallback": ""
      }
    }
  ]
}
```
