# DeepSeek Harness 文档式插件

项目：未命名插件
冻结插件 ID：apd-guide-d1a844b8-3df49f43e901f90292108f0492c2e6fb
已验证文档工具 API：DeepSeek Harness 0.2.1-rc.3、0.2.1-rc.5；不声明其他版本兼容。

CLI / Web：解压到固定目录，使用你希望运行的 web profile：

dsh plugin --profile web add /absolute/path/to/apd-guide-d1a844b8-3df49f43e901f90292108f0492c2e6fb
dsh --profile web --dump-config
dsh --profile web

显式选择工具 apd_guide_d1a844b8_3df49f43e901f90292108f0492c2e6fb_guide，参数为 {}。该只读工具仅返回 WORKFLOW.md 全文；大模型依据说明书理解和使用流程，不能把读取文档当成任务已完成。文档与设计器预览、Markdown 下载完全相同。本包不含执行器，不要求子会话提供器或额外 Node 版本；宿主自身运行环境按宿主安装要求。不会运行任务、安装脚本或修改权限。草稿与缺失宿主能力需向用户说明并询问。

桌面版：CLI 的 web/workflow profile 与 Electron 的 desktop profile 独立，以上安装不会进入当前桌面会话。先启动一次桌面应用完成初始化，再完全退出。使用该桌面安装自带 resources/runtime/cli/bin/dsh（Windows 为 dsh.cmd，不能换成 npm 全局 dsh），执行 plugin --profile desktop add /absolute/path/to/apd-guide-d1a844b8-3df49f43e901f90292108f0492c2e6fb，再重新打开桌面。需以该桌面内置命令 --version 核对版本。npm CLI 不能管理 desktop；这里仅核实官方源码和 CLI 原生工具 API，未实际验收桌面 UI。

使用时给模型明确指令：调用 apd_guide_d1a844b8_3df49f43e901f90292108f0492c2e6fb_guide，参数 {}，先读取完整说明书，再按说明书处理我的任务。工具返回全文只表示文档已读取，不表示流程已执行完成。

移除：对应 CLI / Web 使用 dsh plugin --profile web remove apd-guide-d1a844b8-3df49f43e901f90292108f0492c2e6fb；桌面退出后使用桌面内置命令 plugin --profile desktop remove apd-guide-d1a844b8-3df49f43e901f90292108f0492c2e6fb

项目原版本："1.0.0"；安装包版本：1.0.0。非语义项目版本仅在原生包清单使用 0.0.0，原项目与说明书保持不变。
