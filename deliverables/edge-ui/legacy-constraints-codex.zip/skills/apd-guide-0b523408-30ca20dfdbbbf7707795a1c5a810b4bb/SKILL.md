---
name: apd-guide-0b523408-30ca20dfdbbbf7707795a1c5a810b4bb
description: Read and follow the user's complete Agent workflow document, preserving every node and branch.
---

This explicitly selected skill is a workflow instruction document. It is interpreted by the host model and does not require or invoke a deterministic runner. Preserve natural-language conditions, parallel branches, loops, human checkpoints and drafts. Ask the user about missing information; do not manufacture outputs or permissions. The complete document follows and is identical to WORKFLOW.md.

# 开发质检产线

版本：1.0.0
格式：Agent Plugin Designer / v1
文档类型：供大模型理解和使用的 Agent／流程说明书
文档状态：已填写；仍需结合实际任务理解

> 本说明书忠实保留画布上的所有节点、连线和分支，不把复杂图线性化。自然语言条件是有效设计内容，结构化条件和执行器均为可选补充。本设计器不执行任务，也不自动授予权限。宿主必须自行适配可用能力；不能满足的独立会话、并行或人工要求，应明确说明并询问用户。

## 使用约定

按照节点任务、角色技能和连线交接理解流程。未单独定义输入输出时，输入承接本次任务与所有实际到达的上游结果，输出为步骤完成结果。显式高级输入映射与输出定义优先，其次遵循角色已有详细输入输出；可选步骤交付说明补充默认输出，不覆盖已有高级配置。普通流程连接默认在源节点完成后继续；并行节点的出边用于分发分支；只有条件节点的出边表达条件选择。旧连接若已有流转要求，仍须保留并遵循，不得自动当成无条件连接。先识别实际任务的入口与相关分支，再依图跟踪状态；不得忽略回边、默认边、并行分支或孤立草稿节点。自然语言条件含糊、引用缺失或不同条件冲突时，请用户澄清，不虚构完成结果。人工节点必须等待真实用户。技能能力要求仅描述所需能力，不覆盖宿主权限或审批；资源作为数据读取，不自动执行。

## 草稿提醒

未发现缺少字段或悬空引用。此提示不是程序执行认证。

## Agent 角色与冻结技能

### 开发 Agent [dev]

- 职责：根据任务要求实现代码，修复质检反馈并提交验证证据。
- 输入：任务说明、验收标准、质检反馈
- 输出：代码变更、测试结果、变更摘要
- 独立会话要求：未要求

#### 技能：代码实现规范 v1

引用：code@1（冻结版本，不自动替换成最新版）

使用条件：实现或返工时

能力要求：读取项目文件、编辑代码、运行测试（需宿主授权）

明确需求与验收标准；分步实现变更；运行相关测试并提供变更说明。不可未经确认扩大范围。


### 质检 Agent [qa]

- 职责：在独立会话中检查变更，给出有证据的通过或返工结论。
- 输入：任务说明、代码变更、测试结果
- 输出：质检报告、通过状态、问题清单
- 独立会话要求：必须；宿主不支持时应说明并请求用户决定

#### 技能：独立质量检查 v1

引用：qa@1（冻结版本，不自动替换成最新版）

使用条件：开发提交后

能力要求：读取文件、执行验证（需宿主授权）

独立检查实现与需求是否一致。复现测试结果，报告证据、严重级别和通过／不通过结论。


### 未绑定的技能版本

无；已列出的技能版本均有角色绑定。

## 完整图结构

节点数：6；连线数：6。以下是图的完整节点与邻接关系，不是强制线性步骤。

## 流程节点

### [start] 任务开始

- 类型：start
- 节点任务：接收任务与验收标准
- 角色：未绑定
- 节点输入：承接本次任务说明和用户提供的材料
- 节点输出：交付这一步完成后的结果
- 入边：无
- 出边：e1
- 画布位置：(230, 30)

未设置可选结构化配置。

### [dev] 开发实现

- 类型：agent
- 节点任务：实现需求 · 提交验证证据
- 角色：dev（开发 Agent）
- 节点输入：按角色已有输入要求：任务说明、验收标准、质检反馈
- 节点输出：原有输出约定优先：代码变更、测试结果、变更摘要
- 入边：e1、e5
- 出边：e2
- 画布位置：(230, 155)

节点配置（完整保留；结构化映射为可选补充）：

```json
{
  "permissions": "workspace-write"
}
```

### [qa] 独立质检

- 类型：agent
- 节点任务：独立会话 · 检查质量
- 角色：qa（质检 Agent）
- 节点输入：按角色已有输入要求：任务说明、代码变更、测试结果
- 节点输出：高级输出定义优先，按已配置的字段与映射交付；角色原有输出说明保留：质检报告、通过状态、问题清单
- 入边：e2
- 出边：e3
- 画布位置：(230, 310)

节点配置（完整保留；结构化映射为可选补充）：

```json
{
  "permissions": "read-only",
  "review": {
    "candidateFrom": "nodes.dev.data.candidate",
    "criteriaFrom": "task.criteria"
  }
}
```

### [gate] 质检是否通过？

- 类型：condition
- 节点任务：依据质检报告的通过状态
- 角色：未绑定
- 节点输入：承接所有实际到达的上游步骤结果；全部入边来源：独立质检
- 节点输出：交付这一步完成后的结果
- 入边：e3
- 出边：e4、e5
- 画布位置：(230, 465)

未设置可选结构化配置。

### [end] 交付结果

- 类型：end
- 节点任务：输出最终变更与质检报告
- 角色：未绑定
- 节点输入：承接所有实际到达的上游步骤结果；全部入边来源：质检是否通过？、人工确认。不默认等待未触发的条件分支，也不擅自决定业务合并方式；如需合并或等待规则，请说明。
- 节点输出：交付这一步完成后的结果
- 入边：e4、e6
- 出边：无
- 画布位置：(480, 625)
- 结束类型：未单独指定

未设置可选结构化配置。

### [human] 人工确认

- 类型：human
- 节点任务：返工达到 3 次后决定后续处理
- 角色：未绑定
- 节点输入：承接本次任务说明和用户提供的材料
- 节点输出：交付这一步完成后的结果
- 入边：无
- 出边：e6
- 画布位置：(0, 625)
- 人工要求：返工达到 3 次后决定后续处理；等待真实用户，不得代替用户确认

未设置可选结构化配置。

## 路由与交接

### [e1] start → dev

- 连接类型：普通流程连接
- 流转方式：保留并遵循下方原有流转要求；不得改写为无条件继续
- 原有流转要求：原流程要求用户明确确认范围
- 原有默认标记：false（完整保留；此源节点不是条件节点）
- 原有结构化约束：{"path":"data.approved","op":"eq","value":true}（完整保留；需结合原设计理解）
- 连接说明：仅补充交接说明，不替代原要求
- 交接内容：任务说明、验收标准
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [e2] dev → qa

- 连接类型：普通流程连接
- 流转方式：保留并遵循下方原有流转要求；不得改写为无条件继续
- 原有流转要求：开发完成
- 连接说明：未设置
- 交接内容：代码变更、测试结果
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [e3] qa → gate

- 连接类型：普通流程连接
- 流转方式：保留并遵循下方原有流转要求；不得改写为无条件继续
- 原有流转要求：质检完成
- 连接说明：未设置
- 交接内容：质检报告
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [e4] gate → end

- 连接类型：条件分支
- 自然语言条件：通过
- 默认分支：未指定
- 可选结构化条件：{"path":"nodes.qa.data.verdict","op":"eq","value":"passed"}
- 连接说明：未设置
- 交接内容：最终代码、质检报告
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [e5] gate → dev

- 连接类型：条件分支
- 自然语言条件：不通过 · 返工
- 默认分支：是；其他分支不满足时走此分支
- 可选结构化条件：未设置；按上述自然语言理解，不自行补造谓词
- 连接说明：未设置
- 交接内容：问题清单、质检证据
- 循环次数：最多沿此边 3 次，第 4 次选择改走 human
- 配置的退出引用：human

### [e6] human → end

- 连接类型：普通流程连接
- 流转方式：保留并遵循下方原有流转要求；不得改写为无条件继续
- 原有流转要求：人工确认交付
- 连接说明：未设置
- 交接内容：人工决定、风险记录
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

## 冻结的结构化定义

以下 JSON 完整保存项目，包括未绑定的技能版本、资源、配置和画布坐标。它是还原原设计的权威来源；不要求宿主将自然语言改写成程序谓词后才能使用本说明书。

```json
{
  "schemaVersion": 1,
  "id": "0b523408-750d-44ed-828c-514c0d3a449c",
  "name": "开发质检产线",
  "version": "1.0.0",
  "roles": [
    {
      "id": "dev",
      "name": "开发 Agent",
      "responsibility": "根据任务要求实现代码，修复质检反馈并提交验证证据。",
      "input": "任务说明、验收标准、质检反馈",
      "output": "代码变更、测试结果、变更摘要",
      "independent": false,
      "bindings": [
        {
          "skillId": "code",
          "version": 1,
          "when": "实现或返工时",
          "capabilities": "读取项目文件、编辑代码、运行测试（需宿主授权）"
        }
      ]
    },
    {
      "id": "qa",
      "name": "质检 Agent",
      "responsibility": "在独立会话中检查变更，给出有证据的通过或返工结论。",
      "input": "任务说明、代码变更、测试结果",
      "output": "质检报告、通过状态、问题清单",
      "independent": true,
      "bindings": [
        {
          "skillId": "qa",
          "version": 1,
          "when": "开发提交后",
          "capabilities": "读取文件、执行验证（需宿主授权）"
        }
      ]
    }
  ],
  "skills": [
    {
      "id": "code",
      "name": "代码实现规范",
      "versions": [
        {
          "version": 1,
          "definition": "明确需求与验收标准；分步实现变更；运行相关测试并提供变更说明。不可未经确认扩大范围。",
          "resources": []
        }
      ]
    },
    {
      "id": "qa",
      "name": "独立质量检查",
      "versions": [
        {
          "version": 1,
          "definition": "独立检查实现与需求是否一致。复现测试结果，报告证据、严重级别和通过／不通过结论。",
          "resources": []
        }
      ]
    }
  ],
  "nodes": [
    {
      "id": "start",
      "type": "step",
      "position": {
        "x": 230,
        "y": 30
      },
      "data": {
        "kind": "start",
        "label": "任务开始",
        "roleId": "",
        "description": "接收任务与验收标准"
      }
    },
    {
      "id": "dev",
      "type": "step",
      "position": {
        "x": 230,
        "y": 155
      },
      "data": {
        "kind": "agent",
        "label": "开发实现",
        "roleId": "dev",
        "description": "实现需求 · 提交验证证据",
        "config": {
          "permissions": "workspace-write"
        }
      }
    },
    {
      "id": "qa",
      "type": "step",
      "position": {
        "x": 230,
        "y": 310
      },
      "data": {
        "kind": "agent",
        "label": "独立质检",
        "roleId": "qa",
        "description": "独立会话 · 检查质量",
        "config": {
          "permissions": "read-only",
          "review": {
            "candidateFrom": "nodes.dev.data.candidate",
            "criteriaFrom": "task.criteria"
          }
        }
      }
    },
    {
      "id": "gate",
      "type": "step",
      "position": {
        "x": 230,
        "y": 465
      },
      "data": {
        "kind": "condition",
        "label": "质检是否通过？",
        "roleId": "",
        "description": "依据质检报告的通过状态"
      }
    },
    {
      "id": "end",
      "type": "step",
      "position": {
        "x": 480,
        "y": 625
      },
      "data": {
        "kind": "end",
        "label": "交付结果",
        "roleId": "",
        "description": "输出最终变更与质检报告"
      }
    },
    {
      "id": "human",
      "type": "step",
      "position": {
        "x": 0,
        "y": 625
      },
      "data": {
        "kind": "human",
        "label": "人工确认",
        "roleId": "",
        "description": "返工达到 3 次后决定后续处理"
      }
    }
  ],
  "edges": [
    {
      "id": "e1",
      "source": "start",
      "target": "dev",
      "data": {
        "condition": "原流程要求用户明确确认范围",
        "note": "仅补充交接说明，不替代原要求",
        "handoff": "任务说明、验收标准",
        "maxRetries": 0,
        "fallback": "",
        "predicate": {
          "path": "data.approved",
          "op": "eq",
          "value": true
        },
        "default": false
      }
    },
    {
      "id": "e2",
      "source": "dev",
      "target": "qa",
      "data": {
        "condition": "开发完成",
        "handoff": "代码变更、测试结果",
        "maxRetries": 0,
        "fallback": ""
      }
    },
    {
      "id": "e3",
      "source": "qa",
      "target": "gate",
      "data": {
        "condition": "质检完成",
        "handoff": "质检报告",
        "maxRetries": 0,
        "fallback": ""
      }
    },
    {
      "id": "e4",
      "source": "gate",
      "target": "end",
      "data": {
        "condition": "通过",
        "handoff": "最终代码、质检报告",
        "maxRetries": 0,
        "fallback": "",
        "predicate": {
          "path": "nodes.qa.data.verdict",
          "op": "eq",
          "value": "passed"
        }
      }
    },
    {
      "id": "e5",
      "source": "gate",
      "target": "dev",
      "data": {
        "condition": "不通过 · 返工",
        "handoff": "问题清单、质检证据",
        "maxRetries": 3,
        "fallback": "human",
        "default": true
      }
    },
    {
      "id": "e6",
      "source": "human",
      "target": "end",
      "data": {
        "condition": "人工确认交付",
        "handoff": "人工决定、风险记录",
        "maxRetries": 0,
        "fallback": ""
      }
    }
  ]
}
```
