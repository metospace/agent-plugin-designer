# Codex 0.159.0-alpha.3

Extract to a permanent directory. Node >=24.9.0 required. Host execution verified on Linux; Windows/WSL host runtime not verified. Windows requires user-owned APD_CODEX_BIN pointing to native codex.exe (no cmd/bat shims or shell execution). Before starting the main Codex host, the user sets APD_CODEX_DEVELOPER_SANDBOX=workspace-write to authorize developer writes in the chosen workspace, or read-only for a read-only task. Missing opt-in blocks execution; task JSON cannot grant permission. QA always read-only. Independently launched CLI children cannot infer parent runtime sandbox overrides.

From that directory:

`codex plugin marketplace add .`

`codex plugin add apd-3c89f741-544-772c7fd9c5c446b157c1238e64fbcd7f@apd-3c89f741-544-772c7fd9c5c446b157c1238e64fbcd7f-market`

`codex plugin list`

Select this plugin explicitly in a task and invoke $apd-3c89f741-544-772c7fd9c5c446b157c1238e64fbcd7f:apd-3c89f741-544-772c7fd9c5c446b157c1238e64fbcd7f. Check that the host exposes independent subagent tools before execution. Scripts do not alter permissions or config.

Remove: `codex plugin remove apd-3c89f741-544-772c7fd9c5c446b157c1238e64fbcd7f@apd-3c89f741-544-772c7fd9c5c446b157c1238e64fbcd7f-market`.

State lives at the task path you explicitly choose. Keep .backup for recovery. Project schema 1 is preserved verbatim in project.agent-project.json; execution contract schema 3 is separate.
