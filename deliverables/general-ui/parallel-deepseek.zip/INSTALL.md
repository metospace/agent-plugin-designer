# DeepSeek Harness 0.2.1-rc.5

Node >=24.9.0 required. Extract to a permanent directory, then:

`dsh plugin --profile workflow add /absolute/path/to/apd-fdbabefb-f9e-64f36ff6021ebc871715e876ac86243a`

`dsh --profile workflow --dump-config`

`dsh --profile workflow`

Select tool `apd_fdbabefb_f9e_64f36ff6021ebc871715e876ac86243a_run` in the task. The host main agent must expose native independent subagent tools; absence blocks execution. Multiple bundles use unique package, row and tool names.

Remove: `dsh plugin --profile workflow remove apd-fdbabefb-f9e-64f36ff6021ebc871715e876ac86243a`.

No install scripts or permission grants. Keep original project.agent-project.json and state .backup.
