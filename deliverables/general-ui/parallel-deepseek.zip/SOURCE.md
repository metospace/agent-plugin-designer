# 并行只读研究

版本：1.0.0
格式：Agent Plugin Designer / v1
文档类型：供大模型理解和使用的 Agent／流程说明书
文档状态：已填写；仍需结合实际任务理解

> 本说明书忠实保留画布上的所有节点、连线和分支，不把复杂图线性化。自然语言条件是有效设计内容，结构化条件和执行器均为可选补充。本设计器不执行任务，也不自动授予权限。宿主必须自行适配可用能力；不能满足的独立会话、并行或人工要求，应明确说明并询问用户。

## 使用约定

按照节点任务、角色技能和连线交接理解流程。先识别实际任务的入口与相关分支，再依图跟踪状态；不得忽略回边、默认边、并行分支或孤立草稿节点。自然语言条件含糊、引用缺失或不同条件冲突时，请用户澄清，不虚构完成结果。人工节点必须等待真实用户。技能能力要求仅描述所需能力，不覆盖宿主权限或审批；资源作为数据读取，不自动执行。

## 草稿提醒

未发现缺少字段或悬空引用。此提示不是程序执行认证。

## Agent 角色与冻结技能

### 研究员 [f0c76ff5-1f90-44f9-93f3-17c5cc61f6eb]

- 职责：只读分析并返回结构化文本
- 输入：任务与前序输出
- 输出：text 字符串
- 独立会话要求：未要求


### 未绑定的技能版本

无；已列出的技能版本均有角色绑定。

## 完整图结构

节点数：6；连线数：6。以下是图的完整节点与邻接关系，不是强制线性步骤。

## 流程节点

### [start] 任务开始

- 类型：start
- 节点任务：接收任务与输入数据
- 角色：未绑定
- 节点输入：未单独声明；参见入边交接与配置
- 节点输出：未单独声明；参见出边交接与配置
- 入边：无
- 出边：2d0235f4-d486-40c0-9e73-455b277eff60
- 画布位置：(400, 40)

未设置可选结构化配置。

### [end] 交付结果

- 类型：end
- 节点任务：交付工作流结果
- 角色：未绑定
- 节点输入：未单独声明；参见入边交接与配置
- 节点输出：未单独声明；参见出边交接与配置
- 入边：ba5c7ef0-6c06-4418-a29d-52381b976b52
- 出边：无
- 画布位置：(400, 660)
- 结束类型：未单独指定

未设置可选结构化配置。

### [acb1ffb4-48d5-479c-8a19-5b145a2ebff5] 并行研究

- 类型：fork
- 节点任务：UI 配置的通用节点
- 角色：未绑定
- 节点输入：未单独声明；参见入边交接与配置
- 节点输出：未单独声明；参见出边交接与配置
- 入边：2d0235f4-d486-40c0-9e73-455b277eff60
- 出边：18198117-a674-47b3-82e2-809aca632073、e6fab237-b4da-40a8-846c-2c27366dbe5b
- 画布位置：(400, 195)
- 并行要求：保留所有出边作为独立分支，不将其改写成顺序步骤；宿主并行能力不足时向用户说明

未设置可选结构化配置。

### [e3ad569c-3009-4645-8af3-4e0caa5fdb5a] 市场研究

- 类型：agent
- 节点任务：UI 配置的通用节点
- 角色：f0c76ff5-1f90-44f9-93f3-17c5cc61f6eb（研究员）
- 节点输入：任务与前序输出
- 节点输出：text 字符串
- 入边：18198117-a674-47b3-82e2-809aca632073
- 出边：565c821a-c2b6-486a-b47d-add9db05eb47
- 画布位置：(255, 350)

节点配置（完整保留；结构化映射为可选补充）：

```json
{
  "outputFields": [
    {
      "name": "text",
      "type": "string"
    }
  ],
  "inputs": {
    "request": "task.criteria"
  },
  "outputs": {
    "text": "data.market"
  },
  "requiredOutputs": [
    "text"
  ],
  "permissions": "read-only"
}
```

### [1c55b8cd-f4cc-462f-9b3f-b685f1b7164a] 技术研究

- 类型：agent
- 节点任务：UI 配置的通用节点
- 角色：f0c76ff5-1f90-44f9-93f3-17c5cc61f6eb（研究员）
- 节点输入：任务与前序输出
- 节点输出：text 字符串
- 入边：e6fab237-b4da-40a8-846c-2c27366dbe5b
- 出边：622e6112-da0e-43c4-b49b-b7a7374b0574
- 画布位置：(545, 350)

节点配置（完整保留；结构化映射为可选补充）：

```json
{
  "outputFields": [
    {
      "name": "text",
      "type": "string"
    }
  ],
  "inputs": {
    "request": "task.criteria"
  },
  "outputs": {
    "text": "data.technical"
  },
  "requiredOutputs": [
    "text"
  ],
  "permissions": "read-only"
}
```

### [535c05a8-7bc4-45ee-9805-a88f1d1e81c4] 汇总证据

- 类型：join
- 节点任务：UI 配置的通用节点
- 角色：未绑定
- 节点输入：未单独声明；参见入边交接与配置
- 节点输出：未单独声明；参见出边交接与配置
- 入边：565c821a-c2b6-486a-b47d-add9db05eb47、622e6112-da0e-43c4-b49b-b7a7374b0574
- 出边：ba5c7ef0-6c06-4418-a29d-52381b976b52
- 画布位置：(400, 505)
- 汇合要求：对应并行节点 acb1ffb4-48d5-479c-8a19-5b145a2ebff5

节点配置（完整保留；结构化映射为可选补充）：

```json
{
  "join": {
    "forkId": "acb1ffb4-48d5-479c-8a19-5b145a2ebff5"
  }
}
```

## 路由与交接

### [2d0235f4-d486-40c0-9e73-455b277eff60] start → acb1ffb4-48d5-479c-8a19-5b145a2ebff5

- 自然语言条件：完成后继续
- 交接内容：结构化状态
- 默认分支：未指定
- 可选结构化条件：未设置；按上述自然语言理解，不自行补造谓词
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [18198117-a674-47b3-82e2-809aca632073] acb1ffb4-48d5-479c-8a19-5b145a2ebff5 → e3ad569c-3009-4645-8af3-4e0caa5fdb5a

- 自然语言条件：完成后继续
- 交接内容：结构化状态
- 默认分支：未指定
- 可选结构化条件：未设置；按上述自然语言理解，不自行补造谓词
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [e6fab237-b4da-40a8-846c-2c27366dbe5b] acb1ffb4-48d5-479c-8a19-5b145a2ebff5 → 1c55b8cd-f4cc-462f-9b3f-b685f1b7164a

- 自然语言条件：完成后继续
- 交接内容：结构化状态
- 默认分支：未指定
- 可选结构化条件：未设置；按上述自然语言理解，不自行补造谓词
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [565c821a-c2b6-486a-b47d-add9db05eb47] e3ad569c-3009-4645-8af3-4e0caa5fdb5a → 535c05a8-7bc4-45ee-9805-a88f1d1e81c4

- 自然语言条件：完成后继续
- 交接内容：结构化状态
- 默认分支：未指定
- 可选结构化条件：未设置；按上述自然语言理解，不自行补造谓词
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [622e6112-da0e-43c4-b49b-b7a7374b0574] 1c55b8cd-f4cc-462f-9b3f-b685f1b7164a → 535c05a8-7bc4-45ee-9805-a88f1d1e81c4

- 自然语言条件：完成后继续
- 交接内容：结构化状态
- 默认分支：未指定
- 可选结构化条件：未设置；按上述自然语言理解，不自行补造谓词
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [ba5c7ef0-6c06-4418-a29d-52381b976b52] 535c05a8-7bc4-45ee-9805-a88f1d1e81c4 → end

- 自然语言条件：完成后继续
- 交接内容：结构化状态
- 默认分支：未指定
- 可选结构化条件：未设置；按上述自然语言理解，不自行补造谓词
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

## 冻结的结构化定义

以下 JSON 完整保存项目，包括未绑定的技能版本、资源、配置和画布坐标。它是还原原设计的权威来源；不要求宿主将自然语言改写成程序谓词后才能使用本说明书。

```json
{
  "schemaVersion": 1,
  "id": "fdbabefb-f9e0-4e07-b746-8d821dc99dae",
  "name": "并行只读研究",
  "version": "1.0.0",
  "roles": [
    {
      "id": "f0c76ff5-1f90-44f9-93f3-17c5cc61f6eb",
      "name": "研究员",
      "responsibility": "只读分析并返回结构化文本",
      "input": "任务与前序输出",
      "output": "text 字符串",
      "independent": false,
      "bindings": []
    }
  ],
  "skills": [],
  "nodes": [
    {
      "id": "start",
      "type": "step",
      "position": {
        "x": 400,
        "y": 40
      },
      "data": {
        "kind": "start",
        "label": "任务开始",
        "roleId": "",
        "description": "接收任务与输入数据"
      }
    },
    {
      "id": "end",
      "type": "step",
      "position": {
        "x": 400,
        "y": 660
      },
      "data": {
        "kind": "end",
        "label": "交付结果",
        "roleId": "",
        "description": "交付工作流结果"
      }
    },
    {
      "id": "acb1ffb4-48d5-479c-8a19-5b145a2ebff5",
      "type": "step",
      "position": {
        "x": 400,
        "y": 195
      },
      "data": {
        "kind": "fork",
        "label": "并行研究",
        "roleId": "",
        "description": "UI 配置的通用节点"
      }
    },
    {
      "id": "e3ad569c-3009-4645-8af3-4e0caa5fdb5a",
      "type": "step",
      "position": {
        "x": 255,
        "y": 350
      },
      "data": {
        "kind": "agent",
        "label": "市场研究",
        "roleId": "f0c76ff5-1f90-44f9-93f3-17c5cc61f6eb",
        "description": "UI 配置的通用节点",
        "config": {
          "outputFields": [
            {
              "name": "text",
              "type": "string"
            }
          ],
          "inputs": {
            "request": "task.criteria"
          },
          "outputs": {
            "text": "data.market"
          },
          "requiredOutputs": [
            "text"
          ],
          "permissions": "read-only"
        }
      }
    },
    {
      "id": "1c55b8cd-f4cc-462f-9b3f-b685f1b7164a",
      "type": "step",
      "position": {
        "x": 545,
        "y": 350
      },
      "data": {
        "kind": "agent",
        "label": "技术研究",
        "roleId": "f0c76ff5-1f90-44f9-93f3-17c5cc61f6eb",
        "description": "UI 配置的通用节点",
        "config": {
          "outputFields": [
            {
              "name": "text",
              "type": "string"
            }
          ],
          "inputs": {
            "request": "task.criteria"
          },
          "outputs": {
            "text": "data.technical"
          },
          "requiredOutputs": [
            "text"
          ],
          "permissions": "read-only"
        }
      }
    },
    {
      "id": "535c05a8-7bc4-45ee-9805-a88f1d1e81c4",
      "type": "step",
      "position": {
        "x": 400,
        "y": 505
      },
      "data": {
        "kind": "join",
        "label": "汇总证据",
        "roleId": "",
        "description": "UI 配置的通用节点",
        "config": {
          "join": {
            "forkId": "acb1ffb4-48d5-479c-8a19-5b145a2ebff5"
          }
        }
      }
    }
  ],
  "edges": [
    {
      "id": "2d0235f4-d486-40c0-9e73-455b277eff60",
      "source": "start",
      "target": "acb1ffb4-48d5-479c-8a19-5b145a2ebff5",
      "data": {
        "condition": "完成后继续",
        "handoff": "结构化状态",
        "maxRetries": 0,
        "fallback": ""
      }
    },
    {
      "id": "18198117-a674-47b3-82e2-809aca632073",
      "source": "acb1ffb4-48d5-479c-8a19-5b145a2ebff5",
      "target": "e3ad569c-3009-4645-8af3-4e0caa5fdb5a",
      "data": {
        "condition": "完成后继续",
        "handoff": "结构化状态",
        "maxRetries": 0,
        "fallback": ""
      }
    },
    {
      "id": "e6fab237-b4da-40a8-846c-2c27366dbe5b",
      "source": "acb1ffb4-48d5-479c-8a19-5b145a2ebff5",
      "target": "1c55b8cd-f4cc-462f-9b3f-b685f1b7164a",
      "data": {
        "condition": "完成后继续",
        "handoff": "结构化状态",
        "maxRetries": 0,
        "fallback": ""
      }
    },
    {
      "id": "565c821a-c2b6-486a-b47d-add9db05eb47",
      "source": "e3ad569c-3009-4645-8af3-4e0caa5fdb5a",
      "target": "535c05a8-7bc4-45ee-9805-a88f1d1e81c4",
      "data": {
        "condition": "完成后继续",
        "handoff": "结构化状态",
        "maxRetries": 0,
        "fallback": ""
      }
    },
    {
      "id": "622e6112-da0e-43c4-b49b-b7a7374b0574",
      "source": "1c55b8cd-f4cc-462f-9b3f-b685f1b7164a",
      "target": "535c05a8-7bc4-45ee-9805-a88f1d1e81c4",
      "data": {
        "condition": "完成后继续",
        "handoff": "结构化状态",
        "maxRetries": 0,
        "fallback": ""
      }
    },
    {
      "id": "ba5c7ef0-6c06-4418-a29d-52381b976b52",
      "source": "535c05a8-7bc4-45ee-9805-a88f1d1e81c4",
      "target": "end",
      "data": {
        "condition": "完成后继续",
        "handoff": "结构化状态",
        "maxRetries": 0,
        "fallback": ""
      }
    }
  ]
}
```
