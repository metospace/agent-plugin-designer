# DeepSeek Harness 0.2.1-rc.5

Node >=24.9.0 required. Extract to a permanent directory, then:

`dsh plugin --profile workflow add /absolute/path/to/apd-3c89f741-544-772c7fd9c5c446b157c1238e64fbcd7f`

`dsh --profile workflow --dump-config`

`dsh --profile workflow`

Select tool `apd_3c89f741_544_772c7fd9c5c446b157c1238e64fbcd7f_run` in the task. The host main agent must expose native independent subagent tools; absence blocks execution. Multiple bundles use unique package, row and tool names.

Remove: `dsh plugin --profile workflow remove apd-3c89f741-544-772c7fd9c5c446b157c1238e64fbcd7f`.

No install scripts or permission grants. Keep original project.agent-project.json and state .backup.
