# 多路决策与人工恢复

版本：1.0.0
格式：Agent Plugin Designer / v1
文档类型：供大模型理解和使用的 Agent／流程说明书
文档状态：已填写；仍需结合实际任务理解

> 本说明书忠实保留画布上的所有节点、连线和分支，不把复杂图线性化。自然语言条件是有效设计内容，结构化条件和执行器均为可选补充。本设计器不执行任务，也不自动授予权限。宿主必须自行适配可用能力；不能满足的独立会话、并行或人工要求，应明确说明并询问用户。

## 使用约定

按照节点任务、角色技能和连线交接理解流程。先识别实际任务的入口与相关分支，再依图跟踪状态；不得忽略回边、默认边、并行分支或孤立草稿节点。自然语言条件含糊、引用缺失或不同条件冲突时，请用户澄清，不虚构完成结果。人工节点必须等待真实用户。技能能力要求仅描述所需能力，不覆盖宿主权限或审批；资源作为数据读取，不自动执行。

## 草稿提醒

未发现缺少字段或悬空引用。此提示不是程序执行认证。

## Agent 角色与冻结技能

### 分类分析 [67a81eea-bbf4-4fb8-bcbe-745a16f3c680]

- 职责：只读分析并返回结构化文本
- 输入：任务与前序输出
- 输出：text 字符串
- 独立会话要求：未要求


### 未绑定的技能版本

无；已列出的技能版本均有角色绑定。

## 完整图结构

节点数：6；连线数：6。以下是图的完整节点与邻接关系，不是强制线性步骤。

## 流程节点

### [start] 任务开始

- 类型：start
- 节点任务：接收任务与输入数据
- 角色：未绑定
- 节点输入：未单独声明；参见入边交接与配置
- 节点输出：未单独声明；参见出边交接与配置
- 入边：无
- 出边：cdd7f4f5-8ef8-4c4b-a34e-99bcccf69da9
- 画布位置：(255, 40)

未设置可选结构化配置。

### [end] 交付结果

- 类型：end
- 节点任务：交付工作流结果
- 角色：未绑定
- 节点输入：未单独声明；参见入边交接与配置
- 节点输出：未单独声明；参见出边交接与配置
- 入边：298d97fd-1c76-43f3-9a45-8b5fa35290fd、a04c3d4f-5c27-4bd5-98bf-dd4b3b879c12
- 出边：无
- 画布位置：(255, 505)
- 结束类型：未单独指定

未设置可选结构化配置。

### [75007a71-a338-48db-8a73-cb451c29f106] 风险分类

- 类型：agent
- 节点任务：UI 配置的通用节点
- 角色：67a81eea-bbf4-4fb8-bcbe-745a16f3c680（分类分析）
- 节点输入：任务与前序输出
- 节点输出：text 字符串
- 入边：cdd7f4f5-8ef8-4c4b-a34e-99bcccf69da9、85a1501f-ad4b-4be0-8a4f-232db622deda
- 出边：26f1a34c-24c8-4ad6-8e49-05bb93a17a5d
- 画布位置：(400, 195)

节点配置（完整保留；结构化映射为可选补充）：

```json
{
  "outputFields": [
    {
      "name": "text",
      "type": "string"
    }
  ],
  "inputs": {
    "request": "task.criteria"
  },
  "outputs": {
    "text": "data.route"
  },
  "requiredOutputs": [
    "text"
  ],
  "permissions": "read-only"
}
```

### [76ff424b-6b79-4cca-8849-19eefcfaa0f6] 选择处理

- 类型：condition
- 节点任务：UI 配置的通用节点
- 角色：未绑定
- 节点输入：未单独声明；参见入边交接与配置
- 节点输出：未单独声明；参见出边交接与配置
- 入边：26f1a34c-24c8-4ad6-8e49-05bb93a17a5d
- 出边：298d97fd-1c76-43f3-9a45-8b5fa35290fd、85a1501f-ad4b-4be0-8a4f-232db622deda、5f15edbb-c1b9-46a5-8613-ed727c56867a
- 画布位置：(400, 350)

未设置可选结构化配置。

### [2287bee3-704e-4f83-80e5-ce7354fb215c] 人工决策

- 类型：human
- 节点任务：UI 配置的通用节点
- 角色：未绑定
- 节点输入：未单独声明；参见入边交接与配置
- 节点输出：未单独声明；参见出边交接与配置
- 入边：无
- 出边：a04c3d4f-5c27-4bd5-98bf-dd4b3b879c12
- 画布位置：(545, 40)
- 人工要求：UI 配置的通用节点；等待真实用户，不得代替用户确认

未设置可选结构化配置。

### [085abbe4-188f-439e-a346-601e09e0a27f] 失败退出

- 类型：end
- 节点任务：UI 配置的通用节点
- 角色：未绑定
- 节点输入：未单独声明；参见入边交接与配置
- 节点输出：未单独声明；参见出边交接与配置
- 入边：5f15edbb-c1b9-46a5-8613-ed727c56867a
- 出边：无
- 画布位置：(545, 505)
- 结束类型：failure

节点配置（完整保留；结构化映射为可选补充）：

```json
{
  "terminal": "failure"
}
```

## 路由与交接

### [cdd7f4f5-8ef8-4c4b-a34e-99bcccf69da9] start → 75007a71-a338-48db-8a73-cb451c29f106

- 自然语言条件：完成后继续
- 交接内容：结构化状态
- 默认分支：未指定
- 可选结构化条件：未设置；按上述自然语言理解，不自行补造谓词
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [26f1a34c-24c8-4ad6-8e49-05bb93a17a5d] 75007a71-a338-48db-8a73-cb451c29f106 → 76ff424b-6b79-4cca-8849-19eefcfaa0f6

- 自然语言条件：完成后继续
- 交接内容：结构化状态
- 默认分支：未指定
- 可选结构化条件：未设置；按上述自然语言理解，不自行补造谓词
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [298d97fd-1c76-43f3-9a45-8b5fa35290fd] 76ff424b-6b79-4cca-8849-19eefcfaa0f6 → end

- 自然语言条件：完成后继续
- 交接内容：结构化状态
- 默认分支：未指定
- 可选结构化条件：{"path":"data.route","op":"eq","value":"ok"}
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [85a1501f-ad4b-4be0-8a4f-232db622deda] 76ff424b-6b79-4cca-8849-19eefcfaa0f6 → 75007a71-a338-48db-8a73-cb451c29f106

- 自然语言条件：完成后继续
- 交接内容：结构化状态
- 默认分支：未指定
- 可选结构化条件：{"path":"data.route","op":"eq","value":"retry"}
- 循环次数：最多沿此边 2 次，第 3 次选择改走 2287bee3-704e-4f83-80e5-ce7354fb215c
- 配置的退出引用：2287bee3-704e-4f83-80e5-ce7354fb215c

### [5f15edbb-c1b9-46a5-8613-ed727c56867a] 76ff424b-6b79-4cca-8849-19eefcfaa0f6 → 085abbe4-188f-439e-a346-601e09e0a27f

- 自然语言条件：完成后继续
- 交接内容：结构化状态
- 默认分支：是
- 可选结构化条件：未设置；按上述自然语言理解，不自行补造谓词
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [a04c3d4f-5c27-4bd5-98bf-dd4b3b879c12] 2287bee3-704e-4f83-80e5-ce7354fb215c → end

- 自然语言条件：完成后继续
- 交接内容：结构化状态
- 默认分支：未指定
- 可选结构化条件：未设置；按上述自然语言理解，不自行补造谓词
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

## 冻结的结构化定义

以下 JSON 完整保存项目，包括未绑定的技能版本、资源、配置和画布坐标。它是还原原设计的权威来源；不要求宿主将自然语言改写成程序谓词后才能使用本说明书。

```json
{
  "schemaVersion": 1,
  "id": "3c89f741-5444-4493-82de-2e9c801415c4",
  "name": "多路决策与人工恢复",
  "version": "1.0.0",
  "roles": [
    {
      "id": "67a81eea-bbf4-4fb8-bcbe-745a16f3c680",
      "name": "分类分析",
      "responsibility": "只读分析并返回结构化文本",
      "input": "任务与前序输出",
      "output": "text 字符串",
      "independent": false,
      "bindings": []
    }
  ],
  "skills": [],
  "nodes": [
    {
      "id": "start",
      "type": "step",
      "position": {
        "x": 255,
        "y": 40
      },
      "data": {
        "kind": "start",
        "label": "任务开始",
        "roleId": "",
        "description": "接收任务与输入数据"
      }
    },
    {
      "id": "end",
      "type": "step",
      "position": {
        "x": 255,
        "y": 505
      },
      "data": {
        "kind": "end",
        "label": "交付结果",
        "roleId": "",
        "description": "交付工作流结果"
      }
    },
    {
      "id": "75007a71-a338-48db-8a73-cb451c29f106",
      "type": "step",
      "position": {
        "x": 400,
        "y": 195
      },
      "data": {
        "kind": "agent",
        "label": "风险分类",
        "roleId": "67a81eea-bbf4-4fb8-bcbe-745a16f3c680",
        "description": "UI 配置的通用节点",
        "config": {
          "outputFields": [
            {
              "name": "text",
              "type": "string"
            }
          ],
          "inputs": {
            "request": "task.criteria"
          },
          "outputs": {
            "text": "data.route"
          },
          "requiredOutputs": [
            "text"
          ],
          "permissions": "read-only"
        }
      }
    },
    {
      "id": "76ff424b-6b79-4cca-8849-19eefcfaa0f6",
      "type": "step",
      "position": {
        "x": 400,
        "y": 350
      },
      "data": {
        "kind": "condition",
        "label": "选择处理",
        "roleId": "",
        "description": "UI 配置的通用节点"
      }
    },
    {
      "id": "2287bee3-704e-4f83-80e5-ce7354fb215c",
      "type": "step",
      "position": {
        "x": 545,
        "y": 40
      },
      "data": {
        "kind": "human",
        "label": "人工决策",
        "roleId": "",
        "description": "UI 配置的通用节点"
      }
    },
    {
      "id": "085abbe4-188f-439e-a346-601e09e0a27f",
      "type": "step",
      "position": {
        "x": 545,
        "y": 505
      },
      "data": {
        "kind": "end",
        "label": "失败退出",
        "roleId": "",
        "description": "UI 配置的通用节点",
        "config": {
          "terminal": "failure"
        }
      }
    }
  ],
  "edges": [
    {
      "id": "cdd7f4f5-8ef8-4c4b-a34e-99bcccf69da9",
      "source": "start",
      "target": "75007a71-a338-48db-8a73-cb451c29f106",
      "data": {
        "condition": "完成后继续",
        "handoff": "结构化状态",
        "maxRetries": 0,
        "fallback": ""
      }
    },
    {
      "id": "26f1a34c-24c8-4ad6-8e49-05bb93a17a5d",
      "source": "75007a71-a338-48db-8a73-cb451c29f106",
      "target": "76ff424b-6b79-4cca-8849-19eefcfaa0f6",
      "data": {
        "condition": "完成后继续",
        "handoff": "结构化状态",
        "maxRetries": 0,
        "fallback": ""
      }
    },
    {
      "id": "298d97fd-1c76-43f3-9a45-8b5fa35290fd",
      "source": "76ff424b-6b79-4cca-8849-19eefcfaa0f6",
      "target": "end",
      "data": {
        "condition": "完成后继续",
        "handoff": "结构化状态",
        "maxRetries": 0,
        "fallback": "",
        "predicate": {
          "path": "data.route",
          "op": "eq",
          "value": "ok"
        }
      }
    },
    {
      "id": "85a1501f-ad4b-4be0-8a4f-232db622deda",
      "source": "76ff424b-6b79-4cca-8849-19eefcfaa0f6",
      "target": "75007a71-a338-48db-8a73-cb451c29f106",
      "data": {
        "condition": "完成后继续",
        "handoff": "结构化状态",
        "maxRetries": 2,
        "fallback": "2287bee3-704e-4f83-80e5-ce7354fb215c",
        "predicate": {
          "path": "data.route",
          "op": "eq",
          "value": "retry"
        }
      }
    },
    {
      "id": "5f15edbb-c1b9-46a5-8613-ed727c56867a",
      "source": "76ff424b-6b79-4cca-8849-19eefcfaa0f6",
      "target": "085abbe4-188f-439e-a346-601e09e0a27f",
      "data": {
        "condition": "完成后继续",
        "handoff": "结构化状态",
        "maxRetries": 0,
        "fallback": "",
        "default": true
      }
    },
    {
      "id": "a04c3d4f-5c27-4bd5-98bf-dd4b3b879c12",
      "source": "2287bee3-704e-4f83-80e5-ce7354fb215c",
      "target": "end",
      "data": {
        "condition": "完成后继续",
        "handoff": "结构化状态",
        "maxRetries": 0,
        "fallback": ""
      }
    }
  ]
}
```
