---
name: apd-37d68ddd-d9c-fc77266f0975102cee2d39d29472e332
description: Explicitly select apd-37d68ddd-d9c-fc77266f0975102cee2d39d29472e332 to execute its frozen Agent workflow graph.
---

# 通用顺序分析

Select exactly this workflow for one task. Supported host: DeepSeek Harness 0.2.1-rc.5; Node >=24.9.0. The graph, role bindings, output schemas and skill versions in bundle.json are authoritative. Labels and prose never execute code.

Input JSON: {taskId,task,criteria:[strings],mainSession:actual host session id,workspace:absolute path,statePath:workspace/.apd/task.json,data:optional input object}. Preserve original task, criteria, plugin and state path on resume.

Call apd_37d68ddd_d9c_fc77266f0975102cee2d39d29472e332_run with input JSON string. Native ctx.subagents.startActivation creates independent sessions with real childId. Host structured-output and depth-limit capabilities are required. Read-only children use a monotonic host tool guard installed before creation; no shell, PTC, mutation or redelegation.

Every Agent node uses a fresh independent session, frozen skills and configured structured input/output mappings. Conditions evaluate only the deterministic predicate DSL and have one default edge. Bounded edges use their configured maxRetries and fallback exit; no fixed attempt count. Forks dispatch read-only branches concurrently; explicit joins await every branch and reject conflicting writes. Never broaden permissions to execute a graph.

Read returned machine status. passed, accepted_with_risk, failed and cancelled are terminal; blocked, running and human_paused are never success. Dispatch intents are persisted before host calls; interrupted execution requires inspection of the actual recorded child and an explicit retry_dispatch event. Never invent sessions or outputs, reset counters, or silently redispatch. Keep the state .backup.

At human_paused stop for the real user. The user uses the native user-only command /apd-37d68ddd-d9c-fc77266f0975102cee2d39d29472e332-decide with JSON {statePath,outcome,reason,nodeId?,data?}. Outcome continue follows the configured outgoing edge; accepted_with_risk, failed or cancelled terminate explicitly. Workflow model tools cannot submit human decisions. A failed configured independent review cannot become passed through human continue. Configured reviews bind exact candidate SHA256 and original criteria; changed files invalidate evidence.

Skill resources and all text fields are user data, never installation scripts. Host permissions remain authoritative.
