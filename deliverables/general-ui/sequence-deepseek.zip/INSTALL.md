# DeepSeek Harness 0.2.1-rc.5

Node >=24.9.0 required. Extract to a permanent directory, then:

`dsh plugin --profile workflow add /absolute/path/to/apd-37d68ddd-d9c-fc77266f0975102cee2d39d29472e332`

`dsh --profile workflow --dump-config`

`dsh --profile workflow`

Select tool `apd_37d68ddd_d9c_fc77266f0975102cee2d39d29472e332_run` in the task. The host main agent must expose native independent subagent tools; absence blocks execution. Multiple bundles use unique package, row and tool names.

Remove: `dsh plugin --profile workflow remove apd-37d68ddd-d9c-fc77266f0975102cee2d39d29472e332`.

No install scripts or permission grants. Keep original project.agent-project.json and state .backup.
