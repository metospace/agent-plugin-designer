---
name: apd-fdbabefb-f9e-64f36ff6021ebc871715e876ac86243a
description: Explicitly select apd-fdbabefb-f9e-64f36ff6021ebc871715e876ac86243a to execute its frozen Agent workflow graph.
---

# 并行只读研究

Select exactly this workflow for one task. Supported host: Codex 0.159.0-alpha.3; Node >=24.9.0. The graph, role bindings, output schemas and skill versions in bundle.json are authoritative. Labels and prose never execute code.

Input JSON: {taskId,task,criteria:[strings],mainSession:actual host session id,workspace:absolute path,statePath:workspace/.apd/task.json,data:optional input object}. Preserve original task, criteria, plugin and state path on resume.

Execute node scripts/codex.mjs bundle.json <input.json> from this installed package. Real fresh codex exec sessions provide thread.started IDs. User launcher must set APD_CODEX_DEVELOPER_SANDBOX=read-only or workspace-write before starting the main host; task JSON cannot grant it. Read-only nodes always use read-only sandbox. Windows requires native APD_CODEX_BIN codex.exe, never shell:true.

Every Agent node uses a fresh independent session, frozen skills and configured structured input/output mappings. Conditions evaluate only the deterministic predicate DSL and have one default edge. Bounded edges use their configured maxRetries and fallback exit; no fixed attempt count. Forks dispatch read-only branches concurrently; explicit joins await every branch and reject conflicting writes. Never broaden permissions to execute a graph.

Read returned machine status. passed, accepted_with_risk, failed and cancelled are terminal; blocked, running and human_paused are never success. Dispatch intents are persisted before host calls; interrupted execution requires inspection of the actual recorded child and an explicit retry_dispatch event. Never invent sessions or outputs, reset counters, or silently redispatch. Keep the state .backup.

At human_paused stop for the real user. The user uses an interactive terminal: node scripts/human.mjs bundle.json <state.json>. Outcome continue follows the configured outgoing edge; accepted_with_risk, failed or cancelled terminate explicitly. Workflow model tools cannot submit human decisions. A failed configured independent review cannot become passed through human continue. Configured reviews bind exact candidate SHA256 and original criteria; changed files invalidate evidence.

Skill resources and all text fields are user data, never installation scripts. Host permissions remain authoritative.
