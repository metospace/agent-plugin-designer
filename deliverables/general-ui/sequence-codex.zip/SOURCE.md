# 通用顺序分析

版本：1.0.0
格式：Agent Plugin Designer / v1
文档类型：供大模型理解和使用的 Agent／流程说明书
文档状态：已填写；仍需结合实际任务理解

> 本说明书忠实保留画布上的所有节点、连线和分支，不把复杂图线性化。自然语言条件是有效设计内容，结构化条件和执行器均为可选补充。本设计器不执行任务，也不自动授予权限。宿主必须自行适配可用能力；不能满足的独立会话、并行或人工要求，应明确说明并询问用户。

## 使用约定

按照节点任务、角色技能和连线交接理解流程。先识别实际任务的入口与相关分支，再依图跟踪状态；不得忽略回边、默认边、并行分支或孤立草稿节点。自然语言条件含糊、引用缺失或不同条件冲突时，请用户澄清，不虚构完成结果。人工节点必须等待真实用户。技能能力要求仅描述所需能力，不覆盖宿主权限或审批；资源作为数据读取，不自动执行。

## 草稿提醒

未发现缺少字段或悬空引用。此提示不是程序执行认证。

## Agent 角色与冻结技能

### 资料分析 [e4c8223c-2241-4231-bb17-793567b86a8a]

- 职责：只读分析并返回结构化文本
- 输入：任务与前序输出
- 输出：text 字符串
- 独立会话要求：未要求


### 未绑定的技能版本

无；已列出的技能版本均有角色绑定。

## 完整图结构

节点数：5；连线数：4。以下是图的完整节点与邻接关系，不是强制线性步骤。

## 流程节点

### [start] 任务开始

- 类型：start
- 节点任务：接收任务与输入数据
- 角色：未绑定
- 节点输入：未单独声明；参见入边交接与配置
- 节点输出：未单独声明；参见出边交接与配置
- 入边：无
- 出边：1b996c40-7715-4020-9383-a838eca51177
- 画布位置：(400, 40)

未设置可选结构化配置。

### [end] 交付结果

- 类型：end
- 节点任务：交付工作流结果
- 角色：未绑定
- 节点输入：未单独声明；参见入边交接与配置
- 节点输出：未单独声明；参见出边交接与配置
- 入边：7c724b8c-43c6-4704-8b24-f38350054167
- 出边：无
- 画布位置：(400, 660)
- 结束类型：未单独指定

未设置可选结构化配置。

### [72f84ae9-0a64-4d93-93c8-eb10db413f07] 收集事实

- 类型：agent
- 节点任务：UI 配置的通用节点
- 角色：e4c8223c-2241-4231-bb17-793567b86a8a（资料分析）
- 节点输入：任务与前序输出
- 节点输出：text 字符串
- 入边：1b996c40-7715-4020-9383-a838eca51177
- 出边：d109417d-b8f5-4951-a2da-a9142b8ebfe5
- 画布位置：(400, 195)

节点配置（完整保留；结构化映射为可选补充）：

```json
{
  "outputFields": [
    {
      "name": "text",
      "type": "string"
    }
  ],
  "inputs": {
    "request": "task.criteria"
  },
  "outputs": {
    "text": "data.facts"
  },
  "requiredOutputs": [
    "text"
  ],
  "permissions": "read-only"
}
```

### [e1fe29fb-834e-4b7d-bb56-0f2708df20ce] 生成摘要

- 类型：agent
- 节点任务：UI 配置的通用节点
- 角色：e4c8223c-2241-4231-bb17-793567b86a8a（资料分析）
- 节点输入：任务与前序输出
- 节点输出：text 字符串
- 入边：d109417d-b8f5-4951-a2da-a9142b8ebfe5
- 出边：a67eb6cb-69f1-45ce-b75e-ef03ec4e3d0b
- 画布位置：(400, 350)

节点配置（完整保留；结构化映射为可选补充）：

```json
{
  "outputFields": [
    {
      "name": "text",
      "type": "string"
    }
  ],
  "inputs": {
    "request": "task.criteria"
  },
  "outputs": {
    "text": "data.summary"
  },
  "requiredOutputs": [
    "text"
  ],
  "permissions": "read-only"
}
```

### [7fed4a3e-6f89-4aad-968c-d05d47678af7] 复核摘要

- 类型：agent
- 节点任务：UI 配置的通用节点
- 角色：e4c8223c-2241-4231-bb17-793567b86a8a（资料分析）
- 节点输入：任务与前序输出
- 节点输出：text 字符串
- 入边：a67eb6cb-69f1-45ce-b75e-ef03ec4e3d0b
- 出边：7c724b8c-43c6-4704-8b24-f38350054167
- 画布位置：(400, 505)

节点配置（完整保留；结构化映射为可选补充）：

```json
{
  "outputFields": [
    {
      "name": "text",
      "type": "string"
    }
  ],
  "inputs": {
    "request": "task.criteria"
  },
  "outputs": {
    "text": "data.checked"
  },
  "requiredOutputs": [
    "text"
  ],
  "permissions": "read-only"
}
```

## 路由与交接

### [1b996c40-7715-4020-9383-a838eca51177] start → 72f84ae9-0a64-4d93-93c8-eb10db413f07

- 自然语言条件：完成后继续
- 交接内容：结构化状态
- 默认分支：未指定
- 可选结构化条件：未设置；按上述自然语言理解，不自行补造谓词
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [d109417d-b8f5-4951-a2da-a9142b8ebfe5] 72f84ae9-0a64-4d93-93c8-eb10db413f07 → e1fe29fb-834e-4b7d-bb56-0f2708df20ce

- 自然语言条件：完成后继续
- 交接内容：结构化状态
- 默认分支：未指定
- 可选结构化条件：未设置；按上述自然语言理解，不自行补造谓词
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [a67eb6cb-69f1-45ce-b75e-ef03ec4e3d0b] e1fe29fb-834e-4b7d-bb56-0f2708df20ce → 7fed4a3e-6f89-4aad-968c-d05d47678af7

- 自然语言条件：完成后继续
- 交接内容：结构化状态
- 默认分支：未指定
- 可选结构化条件：未设置；按上述自然语言理解，不自行补造谓词
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

### [7c724b8c-43c6-4704-8b24-f38350054167] 7fed4a3e-6f89-4aad-968c-d05d47678af7 → end

- 自然语言条件：完成后继续
- 交接内容：结构化状态
- 默认分支：未指定
- 可选结构化条件：未设置；按上述自然语言理解，不自行补造谓词
- 循环次数：未设置次数上限；若形成循环，执行前与用户明确停止条件
- 配置的退出引用：无

## 冻结的结构化定义

以下 JSON 完整保存项目，包括未绑定的技能版本、资源、配置和画布坐标。它是还原原设计的权威来源；不要求宿主将自然语言改写成程序谓词后才能使用本说明书。

```json
{
  "schemaVersion": 1,
  "id": "37d68ddd-d9c7-4f33-bf9a-44990c623cf0",
  "name": "通用顺序分析",
  "version": "1.0.0",
  "roles": [
    {
      "id": "e4c8223c-2241-4231-bb17-793567b86a8a",
      "name": "资料分析",
      "responsibility": "只读分析并返回结构化文本",
      "input": "任务与前序输出",
      "output": "text 字符串",
      "independent": false,
      "bindings": []
    }
  ],
  "skills": [],
  "nodes": [
    {
      "id": "start",
      "type": "step",
      "position": {
        "x": 400,
        "y": 40
      },
      "data": {
        "kind": "start",
        "label": "任务开始",
        "roleId": "",
        "description": "接收任务与输入数据"
      }
    },
    {
      "id": "end",
      "type": "step",
      "position": {
        "x": 400,
        "y": 660
      },
      "data": {
        "kind": "end",
        "label": "交付结果",
        "roleId": "",
        "description": "交付工作流结果"
      }
    },
    {
      "id": "72f84ae9-0a64-4d93-93c8-eb10db413f07",
      "type": "step",
      "position": {
        "x": 400,
        "y": 195
      },
      "data": {
        "kind": "agent",
        "label": "收集事实",
        "roleId": "e4c8223c-2241-4231-bb17-793567b86a8a",
        "description": "UI 配置的通用节点",
        "config": {
          "outputFields": [
            {
              "name": "text",
              "type": "string"
            }
          ],
          "inputs": {
            "request": "task.criteria"
          },
          "outputs": {
            "text": "data.facts"
          },
          "requiredOutputs": [
            "text"
          ],
          "permissions": "read-only"
        }
      }
    },
    {
      "id": "e1fe29fb-834e-4b7d-bb56-0f2708df20ce",
      "type": "step",
      "position": {
        "x": 400,
        "y": 350
      },
      "data": {
        "kind": "agent",
        "label": "生成摘要",
        "roleId": "e4c8223c-2241-4231-bb17-793567b86a8a",
        "description": "UI 配置的通用节点",
        "config": {
          "outputFields": [
            {
              "name": "text",
              "type": "string"
            }
          ],
          "inputs": {
            "request": "task.criteria"
          },
          "outputs": {
            "text": "data.summary"
          },
          "requiredOutputs": [
            "text"
          ],
          "permissions": "read-only"
        }
      }
    },
    {
      "id": "7fed4a3e-6f89-4aad-968c-d05d47678af7",
      "type": "step",
      "position": {
        "x": 400,
        "y": 505
      },
      "data": {
        "kind": "agent",
        "label": "复核摘要",
        "roleId": "e4c8223c-2241-4231-bb17-793567b86a8a",
        "description": "UI 配置的通用节点",
        "config": {
          "outputFields": [
            {
              "name": "text",
              "type": "string"
            }
          ],
          "inputs": {
            "request": "task.criteria"
          },
          "outputs": {
            "text": "data.checked"
          },
          "requiredOutputs": [
            "text"
          ],
          "permissions": "read-only"
        }
      }
    }
  ],
  "edges": [
    {
      "id": "1b996c40-7715-4020-9383-a838eca51177",
      "source": "start",
      "target": "72f84ae9-0a64-4d93-93c8-eb10db413f07",
      "data": {
        "condition": "完成后继续",
        "handoff": "结构化状态",
        "maxRetries": 0,
        "fallback": ""
      }
    },
    {
      "id": "d109417d-b8f5-4951-a2da-a9142b8ebfe5",
      "source": "72f84ae9-0a64-4d93-93c8-eb10db413f07",
      "target": "e1fe29fb-834e-4b7d-bb56-0f2708df20ce",
      "data": {
        "condition": "完成后继续",
        "handoff": "结构化状态",
        "maxRetries": 0,
        "fallback": ""
      }
    },
    {
      "id": "a67eb6cb-69f1-45ce-b75e-ef03ec4e3d0b",
      "source": "e1fe29fb-834e-4b7d-bb56-0f2708df20ce",
      "target": "7fed4a3e-6f89-4aad-968c-d05d47678af7",
      "data": {
        "condition": "完成后继续",
        "handoff": "结构化状态",
        "maxRetries": 0,
        "fallback": ""
      }
    },
    {
      "id": "7c724b8c-43c6-4704-8b24-f38350054167",
      "source": "7fed4a3e-6f89-4aad-968c-d05d47678af7",
      "target": "end",
      "data": {
        "condition": "完成后继续",
        "handoff": "结构化状态",
        "maxRetries": 0,
        "fallback": ""
      }
    }
  ]
}
```
