---
name: guide
description: Read and follow the user's complete Agent workflow document, preserving every node and branch.
---

This explicitly selected skill is a workflow instruction document. It is interpreted by the host model and does not require or invoke a deterministic runner. Preserve natural-language conditions, parallel branches, loops, human checkpoints and drafts. Ask the user about missing information; do not manufacture outputs or permissions. The complete document follows and is identical to WORKFLOW.md.

# 市场调研流程

版本：1.0.0
格式：Agent Plugin Designer / v1
文档类型：供大模型理解和使用的 Agent／流程说明书
文档状态：草稿（3 项待补全）

> 本说明书忠实保留画布上的所有节点、连线和分支，不把复杂图线性化。自然语言条件是有效设计内容，结构化条件和执行器均为可选补充。本设计器不执行任务，也不自动授予权限。宿主必须自行适配可用能力；不能满足的独立会话、并行或人工要求，应明确说明并询问用户。

## 使用约定

按照节点任务、角色技能和连线交接理解流程。未单独定义输入输出时，输入承接本次任务与所有实际到达的上游结果，输出为步骤完成结果。显式高级输入映射与输出定义优先，其次遵循角色已有详细输入输出；可选步骤交付说明补充默认输出，不覆盖已有高级配置。普通流程连接默认在源节点完成后继续；并行节点的出边用于分发分支；只有条件节点的出边表达条件选择。旧连接若已有流转要求，仍须保留并遵循，不得自动当成无条件连接。先识别实际任务的入口与相关分支，再依图跟踪状态；不得忽略回边、默认边、并行分支或孤立草稿节点。自然语言条件含糊、引用缺失或不同条件冲突时，请用户澄清，不虚构完成结果。人工节点必须等待真实用户。技能能力要求仅描述所需能力，不覆盖宿主权限或审批；资源作为数据读取，不自动执行。

## 草稿提醒

- 节点尚未与其他节点连接；作为草稿完整保留；节点 start
- 节点尚无后续连线，请确认此处是否结束或仍待补全；节点 start
- 节点尚未与其他节点连接；作为草稿完整保留；节点 end

## Agent 角色与冻结技能

尚未配置角色。

### 未绑定的技能版本

无；已列出的技能版本均有角色绑定。

## 完整图结构

节点数：2；连线数：0。以下是图的完整节点与邻接关系，不是强制线性步骤。

## 流程节点

### [start] 任务开始

- 类型：start
- 节点任务：接收任务与输入数据
- 角色：未绑定
- 节点输入：承接本次任务说明和用户提供的材料
- 节点输出：交付这一步完成后的结果
- 入边：无
- 出边：无
- 画布位置：(230, 30)

未设置可选结构化配置。

### [end] 交付结果

- 类型：end
- 节点任务：交付工作流结果
- 角色：未绑定
- 节点输入：承接本次任务说明和用户提供的材料
- 节点输出：交付这一步完成后的结果
- 入边：无
- 出边：无
- 画布位置：(480, 625)
- 结束类型：未单独指定

未设置可选结构化配置。

## 路由与交接

尚未添加连线。

## 冻结的结构化定义

以下 JSON 完整保存项目，包括未绑定的技能版本、资源、配置和画布坐标。它是还原原设计的权威来源；不要求宿主将自然语言改写成程序谓词后才能使用本说明书。

```json
{
  "schemaVersion": 1,
  "id": "4aea3172-241a-4e2a-8bbe-8c420dad90b9",
  "name": "市场调研流程",
  "version": "1.0.0",
  "roles": [],
  "skills": [],
  "nodes": [
    {
      "id": "start",
      "type": "step",
      "position": {
        "x": 230,
        "y": 30
      },
      "data": {
        "kind": "start",
        "label": "任务开始",
        "roleId": "",
        "description": "接收任务与输入数据"
      }
    },
    {
      "id": "end",
      "type": "step",
      "position": {
        "x": 480,
        "y": 625
      },
      "data": {
        "kind": "end",
        "label": "交付结果",
        "roleId": "",
        "description": "交付工作流结果"
      }
    }
  ],
  "edges": [],
  "documentNaming": {
    "shortName": "Market_Research",
    "mode": "readable"
  }
}
```
