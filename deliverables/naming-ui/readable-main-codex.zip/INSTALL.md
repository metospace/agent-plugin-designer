# Codex 文档／技能式插件

项目：市场调研流程
显示名称：市场调研流程
英文短名：market-research
实际调用：$apd-market-research-98bf0649a3f8-guide:guide
可直接复制的使用指令：
使用流程：市场调研流程
$apd-market-research-98bf0649a3f8-guide:guide
先读取完整说明书，再按该流程处理我的任务。
包安装标识：apd-market-research-98bf0649a3f8-guide
旧 1.4 安装标识：apd-guide-6e4a169f-98bf0649a3f8f1b65ee01f2624834351
旧 1.4 调用：$apd-guide-6e4a169f-98bf0649a3f8f1b65ee01f2624834351:apd-guide-6e4a169f-98bf0649a3f8f1b65ee01f2624834351
命名模式：可读名称
迁移说明：新可读名称与旧安装名独立，可同时保留。旧包继续使用旧调用，不会自动改名或注册别名。选择旧标识兼容模式沿用旧来源标识规则；导入副本保留原来源锚，内容或版本改变仍会产生不同标识。相同旧安装标识的包不能并装；如需更新原安装，请由用户按宿主卸载／更新步骤处理，本包不会自动修改已安装插件。

解压到固定目录：

codex plugin marketplace add .
codex plugin add apd-market-research-98bf0649a3f8-guide@apd-market-research-98bf0649a3f8-guide-market
codex plugin list

任务中显式选择 $apd-market-research-98bf0649a3f8-guide:guide。技能直接包含完整说明书，WORKFLOW.md 与设计器预览、Markdown 下载完全相同。大模型依据文档理解和使用流程；本包不含执行器，不要求 Node 或独立子会话提供器。缺失宿主能力或草稿信息时应说明并询问用户，权限仍由宿主与用户决定。

移除：codex plugin remove apd-market-research-98bf0649a3f8-guide@apd-market-research-98bf0649a3f8-guide-market

项目原版本："1.0.0"；安装包版本：1.0.0。非语义项目版本仅在原生包清单使用 0.0.0，原项目与说明书保持不变。
