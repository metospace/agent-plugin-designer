# DeepSeek Harness 文档式插件

项目：市场调研流程
显示名称：市场调研流程
英文短名：market-research
实际调用：apd_market_research_880e6d77e849_guide
可直接复制的使用指令：
使用流程：市场调研流程
调用 apd_market_research_880e6d77e849_guide，参数 {}。
先读取完整说明书，再按该流程处理我的任务。
包安装标识：apd-market-research-880e6d77e849-guide
旧 1.4 安装标识：apd-guide-4aea3172-880e6d77e849ed630d057c3272a746fe
旧 1.4 调用：apd_guide_4aea3172_880e6d77e849ed630d057c3272a746fe_guide
命名模式：可读名称
迁移说明：新可读名称与旧安装名独立，可同时保留。旧包继续使用旧调用，不会自动改名或注册别名。选择旧标识兼容模式沿用旧来源标识规则；导入副本保留原来源锚，内容或版本改变仍会产生不同标识。相同旧安装标识的包不能并装；如需更新原安装，请由用户按宿主卸载／更新步骤处理，本包不会自动修改已安装插件。
插件管理中的中文名称来自原生 locale meta.title；工具调用名仍为上方 ASCII 名称，不声称工具卡片标题已改为中文。
已验证文档工具 API：DeepSeek Harness 0.2.1-rc.3、0.2.1-rc.5；不声明其他版本兼容。

CLI / Web：解压到固定目录，使用你希望运行的 web profile：

dsh plugin --profile web add /absolute/path/to/apd-market-research-880e6d77e849-guide
dsh --profile web --dump-config
dsh --profile web

显式选择工具 apd_market_research_880e6d77e849_guide，参数为 {}。该只读工具仅返回 WORKFLOW.md 全文；大模型依据说明书理解和使用流程，不能把读取文档当成任务已完成。文档与设计器预览、Markdown 下载完全相同。本包不含执行器，不要求子会话提供器或额外 Node 版本；宿主自身运行环境按宿主安装要求。不会运行任务、安装脚本或修改权限。草稿与缺失宿主能力需向用户说明并询问。

桌面版：CLI 的 web/workflow profile 与 Electron 的 desktop profile 独立，以上安装不会进入当前桌面会话。先启动一次桌面应用完成初始化，再完全退出。使用该桌面安装自带 resources/runtime/cli/bin/dsh（Windows 为 dsh.cmd，不能换成 npm 全局 dsh），执行 plugin --profile desktop add /absolute/path/to/apd-market-research-880e6d77e849-guide，再重新打开桌面。需以该桌面内置命令 --version 核对版本。npm CLI 不能管理 desktop；这里仅核实官方源码和 CLI 原生工具 API，未实际验收桌面 UI。

使用时给模型明确指令：调用 apd_market_research_880e6d77e849_guide，参数 {}，先读取完整说明书，再按说明书处理我的任务。工具返回全文只表示文档已读取，不表示流程已执行完成。

移除：对应 CLI / Web 使用 dsh plugin --profile web remove apd-market-research-880e6d77e849-guide；桌面退出后使用桌面内置命令 plugin --profile desktop remove apd-market-research-880e6d77e849-guide

项目原版本："2.0.0"；安装包版本：2.0.0。非语义项目版本仅在原生包清单使用 0.0.0，原项目与说明书保持不变。
