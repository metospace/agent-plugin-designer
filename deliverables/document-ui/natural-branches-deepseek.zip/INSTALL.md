# DeepSeek Harness 文档式插件

项目：自然语言多路策划
冻结插件 ID：apd-guide-36fbb34f-8ab4e87f83fb4b5044050dc6b124d181

解压到固定目录：

dsh plugin --profile workflow add /absolute/path/to/apd-guide-36fbb34f-8ab4e87f83fb4b5044050dc6b124d181
dsh --profile workflow --dump-config
dsh --profile workflow

显式选择工具 apd_guide_36fbb34f_8ab4e87f83fb4b5044050dc6b124d181_guide，参数为 {}。该只读工具仅返回 WORKFLOW.md 全文；大模型依据说明书理解和使用流程，不能把读取文档当成任务已完成。文档与设计器预览、Markdown 下载完全相同。本包不含执行器，不要求子会话提供器或额外 Node 版本；宿主自身运行环境按宿主安装要求。不会运行任务、安装脚本或修改权限。草稿与缺失宿主能力需向用户说明并询问。

移除：dsh plugin --profile workflow remove apd-guide-36fbb34f-8ab4e87f83fb4b5044050dc6b124d181

项目原版本："1.0.0"；安装包版本：1.0.0。非语义项目版本仅在原生包清单使用 0.0.0，原项目与说明书保持不变。
