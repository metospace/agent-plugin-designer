# Codex 文档／技能式插件

项目：未完成的迭代草稿
冻结插件 ID：apd-guide-8c30b150-e7bb621652aed8ab477197de3b56e3bd

解压到固定目录：

codex plugin marketplace add .
codex plugin add apd-guide-8c30b150-e7bb621652aed8ab477197de3b56e3bd@apd-guide-8c30b150-e7bb621652aed8ab477197de3b56e3bd-market
codex plugin list

任务中显式选择 $apd-guide-8c30b150-e7bb621652aed8ab477197de3b56e3bd:apd-guide-8c30b150-e7bb621652aed8ab477197de3b56e3bd。技能直接包含完整说明书，WORKFLOW.md 与设计器预览、Markdown 下载完全相同。大模型依据文档理解和使用流程；本包不含执行器，不要求 Node 或独立子会话提供器。缺失宿主能力或草稿信息时应说明并询问用户，权限仍由宿主与用户决定。

移除：codex plugin remove apd-guide-8c30b150-e7bb621652aed8ab477197de3b56e3bd@apd-guide-8c30b150-e7bb621652aed8ab477197de3b56e3bd-market

项目原版本："1.0.0"；安装包版本：1.0.0。非语义项目版本仅在原生包清单使用 0.0.0，原项目与说明书保持不变。
